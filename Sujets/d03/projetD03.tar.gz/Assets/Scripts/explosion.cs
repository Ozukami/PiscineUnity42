﻿using UnityEngine;
using System.Collections;

public class explosion : MonoBehaviour {
	
	void explosionEnd () {
		Destroy (gameObject);
	}
}
