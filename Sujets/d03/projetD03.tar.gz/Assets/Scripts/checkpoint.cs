﻿using UnityEngine;
using System.Collections;

public class checkpoint : MonoBehaviour {

	public GameObject nextCheckpoint;
	
}
